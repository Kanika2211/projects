package transportpkg;

import java.util.ArrayList;

public class tlist {
	
	public static ArrayList<installtruck> t2=new ArrayList<installtruck>();

}
