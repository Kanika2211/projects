package transportpkg;

import java.util.ArrayList;
import java.util.List;

public class msave {
	
	String br, user, pw;
	int id,sal;
	
	ArrayList<msave> mslist;
	
	public String getBr() {
		return br;
	}
	public void setBr(String br) {
		this.br = br;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public ArrayList<msave> getMslist() {
		return mslist;
	}

	public void setMslist(ArrayList<msave> mslist) {
		this.mslist = mslist;
	}
}
		
	

