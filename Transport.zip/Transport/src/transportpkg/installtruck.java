package transportpkg;
import java.util.*;

public class installtruck {
	
	int tno;
	String ownername, troutefrom,trouteto;
	
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public String getOwnername() {
		return ownername;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public String getTroutefrom() {
		return troutefrom;
	}
	public void setTroutefrom(String troutefrom) {
		this.troutefrom = troutefrom;
	}
	public String getTrouteto() {
		return trouteto;
	}
	public void setTrouteto(String trouteto) {
		this.trouteto = trouteto;
	}
}
	
	

