package transportpkg;

public abstract class Test {
	
	
	public int a=10;
	
	public static void show(){
		
	}

	

	
	public  void square(){
	}
	}

