package transportpkg;

import java.util.*;

public class findmgr {

	public static ArrayList<findmgr> al = new ArrayList<findmgr>();
	public String branch, name;
	
	findmgr(){}

	findmgr(String branch, String name) {
		this.branch = branch;
		this.name = name;

	}
	
	public boolean equals(Object obj) 
	{
	if (obj == this) 
	{ 
			return true;
	} 
	if (obj == null || obj.getClass() != this.getClass()) 
	{ 
		return false;
	} 
	
	findmgr fm = (findmgr) obj; 
	return(branch == fm.branch || (branch != null)) 
			&& (name == fm.name || (name != null));
	}

	

	public static ArrayList<findmgr> abc() {

		findmgr f1 = new findmgr("Ghaziabad", "Ankit");
		findmgr f2 = new findmgr("Kanpur", "Nikhil");
		findmgr f3 = new findmgr("Ghaziabad", "Aashu");
		findmgr f4 = new findmgr("Ghaziabad", "Ricky");
		findmgr f5 = new findmgr("Delhi", "Riyansh");
		findmgr f6 = new findmgr("Agra", "Ramu");
		findmgr f7 = new findmgr("Agra", "Shamu");
		findmgr f8 = new findmgr("Delhi", "Vaidehi");
		

		al.add(f1);
		al.add(f2);
		al.add(f3);
		al.add(f4);
		al.add(f5);
		al.add(f6);
		al.add(f7);
		al.add(f8);

		return al;

	}
}
