package transportpkg;

public interface aabb {

	String s="bricks";
	int b=2;
	
	void show();
	 void display();
}
