package sample;

/*import transportpkg.aabb.s;*/
import static transportpkg.aabb.*;
import static java.lang.System.*; 
import static transportpkg.Test.*;
import transportpkg.Test;


public class abc {

	public static void main(String[] args) {
		System.out.println(s);
		out.println(b);  
		out.println(a);  

	
		show();
		square();  //?
		
	
	}

	
}
