package Demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller                      //to convert class to servlet and to handle req/res
public class HelloController {
	
   @RequestMapping(value="/",method = RequestMethod.GET)  //without adding the "value" parameter, we need to explicitly mention the url name.
   public String printHello(ModelMap model) {
      model.addAttribute("message", "Hello Spring MVC Framework!");
      return "hello";   //name of jsp which we need to return. control will go to hello web servlet
   }
}