package Regpckg;

import java.io.FileNotFoundException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.servlet.HttpServletBean;

import com.google.gson.stream.JsonReader;

import javax.validation.Valid;

@Controller
public class RegController {

	@ModelAttribute("regUser")  	//will bind the bean class with the object
	public RegBean rb() {
		return new RegBean();
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String printHello() {

		return "Login"; // name of jsp which we need to return. control will go
						// to hello web servlet
	}

	@RequestMapping(value = "/regpage", method = RequestMethod.GET)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String regpage() {

		return "Reg"; // name of jsp which we need to return. control will go to
						// hello web servlet
	}

	@RequestMapping(value = "/savepage", method = RequestMethod.POST)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String save( RegBean reg, Model model,
			HttpServletRequest req, HttpServletResponse res) throws FileNotFoundException {

		List<RegBean> readList = JSONReader.readJSON();
		readList.add(reg);
		boolean status = JSONWriter.WriteJSON(readList);
		if(status){
			System.out.println("Data Write Successfully..");
			System.out.println("Name:" + reg.getName());
			System.out.println("Password:" + reg.getPassword());
			System.out.println("Company Name:" + reg.getCompany());
			System.out.println("Gender:" + reg.getRadios());
			System.out.println("Location:" + reg.getLoc());
			System.out.println("Languages known:" + reg.getLanguages());

			HttpSession ses = req.getSession();
			ses.setAttribute("reg", reg);

			model.addAttribute("message", "user registered");
			return "Login";
		}
		model.addAttribute("message", "Unable To register User.");
		// model.addAttribute("reg", reg);
		return "Login"; // name of jsp which we need to return. control will go
						// to
						// hello web servlet
	}

	@RequestMapping(value = "/loginsuccess", method = RequestMethod.POST)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String success(RegBean loginBean, BindingResult result,
			Model model, HttpServletRequest req, HttpServletResponse res) throws FileNotFoundException {

		System.out.println("TEST : " + result.getFieldErrorCount());
		if (result.hasErrors()) {
			System.out.println("*******" + result.getAllErrors());
			
			return "Login";

		}
		List<RegBean> readList = JSONReader.readJSON();
		for(RegBean bean : readList){
			if(loginBean.getName().equals(bean.getName()) && loginBean.getPassword().equals(bean.getPassword())){
				model.addAttribute("message", "User Login Successfully.");
				model.addAttribute("rbean", bean);
				
				return "Loginsuccess";
			}
		}
		model.addAttribute("message", "imnvalid user");
		return "Login";

		// name of jsp which we need to return. control will go to
		// hello web servlet
	}

}
