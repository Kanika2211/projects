package Regpckg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jruby.compiler.ir.operands.Array;

import com.google.gson.Gson;

public class JSONWriter {

	static public boolean WriteJSON(List<RegBean> list) {
		Gson gson = new Gson();
		try (FileWriter writer = new FileWriter("D:\\user.json")) {

			gson.toJson(list, writer);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	/*public static void main(String[] args) {

		Gson gson = new Gson();
		RegBean reg = new RegBean();
		reg.setCompany("kanichuuu");
		reg.setName("YYYYYYYYYYYYYYYYYYYYYYYYYYYY");

		try {

			List<RegBean> list = JSONReader.readJSON();

			list.add(reg);

			FileWriter writer = new FileWriter("D:\\user.json");
			gson.toJson(list, writer);

			System.out.println("&&&&&&&&&&");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}*/

}
