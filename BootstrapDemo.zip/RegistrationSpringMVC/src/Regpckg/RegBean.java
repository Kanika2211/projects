package Regpckg;

import javax.validation.constraints.*;

import org.hibernate.validator.constraints.NotBlank;

public class RegBean {

	@NotBlank
	@Size(min=2, max=30)
	private String name;
	
	@NotNull
	@Size(min=2, max=30)
	private String password;
	
	@NotBlank
	private String company;
	@NotNull
	private String radios;
	@NotNull
	private String loc;
	@NotNull
	private String languages; 
	
	
	public String getLanguages() {
		return languages;
	}
	public void setLanguages(String languages) {
		this.languages = languages;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRadios() {
		return radios;
	}
	public void setRadios(String radios) {
		this.radios = radios;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "RegBean [name=" + name + ", password=" + password
				+ ", company=" + company + ", radios=" + radios + ", loc="
				+ loc + ", languages=" + languages + "]";
	}
	
	
	
}
