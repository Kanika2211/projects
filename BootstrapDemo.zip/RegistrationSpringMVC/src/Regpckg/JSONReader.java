package Regpckg;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jruby.compiler.ir.operands.Array;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JSONReader {
	
	 static public List<RegBean> readJSON() throws FileNotFoundException{
		 
		 try {
			 BufferedReader reader = new BufferedReader(new FileReader("D:\\user.json")); 
	         Gson gson = new GsonBuilder().create(); 
	         RegBean[] rb = gson.fromJson(reader, RegBean[].class); 
	         System.out.println(rb);
	         
	         List<RegBean> list = new ArrayList<RegBean>(); 
	         list.addAll(Arrays.asList(rb));    
	         
	         System.out.println("size of read list"+list.size());
	         return list;
	         
	 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
		
	 }
	 
	 public static void main(String[] args) throws FileNotFoundException {
		 
		try {
			
	         List<RegBean> list = readJSON();
	      
	         RegBean reg = new RegBean();
	 		reg.setCompany("kanichuuu");
	 		reg.setName("YYYYYYYYYYYYYYYYYYYYYYYYYYYY");
	 		
	 		
	 		List<RegBean> list2 = new ArrayList<>(); 
	 	
	 		list2.add(reg);
	 		list.addAll(list2);
	 		
	 		Gson gson = new Gson();
			String jsonwrite = gson.toJson(list);
			
			FileWriter writer = new FileWriter("D:\\user.json");
			 //Gson gson = new GsonBuilder().create();
		
            //gson.toJson(json, writer);
			writer.write(jsonwrite);
			writer.close();
	         
	         System.out.println("after writing size of list  : "+list.size());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	 
	 
 }
	
		 
	


