package pkg;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
/**
 * This is an example on how to extract text line by line from pdf document
 */
public class GetLinesFromPDF {

	public static List<GetData> ReadFile(String filepath, String search){
		
		Logger log = Logger.getLogger(GetLinesFromPDF.class.getName());
		
		List<GetData> list=new ArrayList<GetData>();
		
		
		log.error("test successful");

		
		//System.out.println("IN GetLinesFromPDF******"+filepath+"*******"+search);
		//final String search = "contained";
		StringBuilder resultStringBuilder = new StringBuilder();
		Set<String> dataList = new LinkedHashSet<String>();
	
		try (PDDocument document = PDDocument.load(new File(filepath))) {		
			
		for (int i = 1; i <= document.getNumberOfPages(); i++) {
				resultStringBuilder.setLength(0);
				PDFTextStripper tStripper = new PDFTextStripper();
				tStripper.setStartPage(i);
				tStripper.setEndPage(i);

				if (!document.isEncrypted()) {
					
					String pdfFileInText = tStripper.getText(document);
					//System.out.println("*******reasdinh file 2*******");			
					
					int lineNumber = 0, lineNum = 0;
					boolean flag = false;
					String lines[] = pdfFileInText.split("\\r?\\n");
				
					for (String line : lines) {
						String answer="";
						GetData gd=new GetData();
						 resultStringBuilder = new StringBuilder();
						 System.out.println(line);
						// System.out.println(line+" : \t"+search+" : \t"+line.toLowerCase().contains(search.toLowerCase()));
						if (!line.isEmpty()
								&& line.toLowerCase().contains(
										search.toLowerCase())) {
							
							gd.setQuestion(search);
							gd.setLineNo(String.valueOf(lineNumber));
							gd.setPageNo(String.valueOf(i));
							
							
							resultStringBuilder.append("\n");
							resultStringBuilder.append("\t" + search + "\t\t"
									+ (i) + "\t\t" + lineNumber + "\t" + "\t");
							flag = true;
							lineNum = 0;
						}
						if (flag) {
							lineNum++;
							if (lineNum > 10) {
								flag = false;
							}
							dataList.add(resultStringBuilder.toString());
							resultStringBuilder.append(line);
							answer+=line;
						}
						gd.setAnswer(answer);
						list.add(gd);
						System.out.println("linen"+lineNumber);
						lineNumber++;
					}
				}
			/*	if(!dataList.contains(resultStringBuilder.toString()))
				dataList.add(resultStringBuilder.toString());*/
			
			}
	
			if (dataList.size() > 0) {
				
				
				System.out.println(list.size()+"********");
				
				System.out.println("\t" + "Question"
						+ "\t Page No. \t Line No." + "\t Answer ");
				for (String s : dataList) {
					System.out.println(s);
				}
				
				/*PrintStream printStream = new PrintStream(
						new FileOutputStream("D:\\testconsole.xls"));
				System.setOut(printStream);
				System.out.println("\t" + "Question"
						+ "\t\t Page No. \t\t Line No." + "\t\t Answer ");
				for (String s1 : dataList) {
					System.out.println(s1);
				}*/
			} else {
				System.out.println("no data found");
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("EXCEPTIOn" +e);
			
		}
		return list;
	}
	
	
}
