package pkg;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;



/**
 * Servlet implementation class FileServlet
 */
@WebServlet("/FileServlet") 	// 100 MB
//@javax.servlet.annotation.MultipartConfig
public class FileServlet extends HttpServlet {
	
	
	// upload settings
    private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE      = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 50; // 50MB
	private static final long serialVersionUID = 1L;
	 private static final String UPLOAD_DIR = System.getProperty("user.dir");
	 static Logger log = Logger.getLogger(FileServlet.class.getName());
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
      
       
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("*************************");
	log.info("inside post method");
		String 	filePath = "";
		String inputName = null;
		String word = "";
		
        try {
        		try {
        	        List<FileItem> multiparts = new ServletFileUpload(
                                             new DiskFileItemFactory()).parseRequest(request);
                  
                    for(FileItem item : multiparts){
                        if(!item.isFormField()){
                            String name = new File(item.getName()).getName();
                            //System.out.println("name : "+name);
                            filePath = UPLOAD_DIR + File.separator + name ;
                            //System.out.println("filePath : "+filePath);
                            
                            item.write( new File(filePath));
                        }
                        
                        if(item.isFormField()){  // Check regular field.
                        	inputName = (String)item.getFieldName(); 
                        	  if(inputName.equalsIgnoreCase("search")){ 
                        	   word = (String)item.getString(); 
                        	 }
                        } 
                        
                    }
               
        			//System.out.println("UserName is: "+word); 
        
                   //File uploaded successfully
                   request.setAttribute("message", "File Uploaded Successfully");
                } catch (Exception ex) {
                	log.error("EXCEPTIOn" +ex);
                	ex.printStackTrace();
                   request.setAttribute("message", "File Upload Failed due to " + ex);
                }          
             
        	
            //System.out.println("!!!!!");
            List<GetData> list = GetLinesFromPDF.ReadFile(filePath, word);
            //System.out.println("**********");
           /* for(GetData bean : list){
            	System.out.println("^^^^^^^:  "+bean.getLineNo());
            }*/
            
            request.setAttribute("dataList", list);
            request.getRequestDispatcher("welcome.jsp").forward(request, response);
            
        } catch (Exception ex) {
        	log.error("EXCEPTIOn" +ex);
        	ex.printStackTrace();
            request.setAttribute("message",
                    "There was an error: " + ex.getMessage());
        }
		 
		/*
		System.out.println("in file servlet");
		String filename=request.getParameter("file");
	
		String filepath=  request.getPathInfo();
		System.out.println(filename);
		System.out.println(word);
		
		if(filename!=null){
			//response.sendRedirect("welcome.jsp");
			System.out.println("inside servlet method");
			GetLinesFromPDF pdf=new GetLinesFromPDF();
			pdf.ReadFile(filepath,word);
			
			
		}*/
	}
	
	
	

}
