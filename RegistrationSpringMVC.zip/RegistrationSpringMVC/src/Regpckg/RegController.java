package Regpckg;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.servlet.HttpServletBean;
import javax.validation.Valid;

@Controller
public class RegController {

	@ModelAttribute("regUser")  
	
	public RegBean rb() {
		return new RegBean();
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String printHello(ModelMap model) {

		return "Login"; // name of jsp which we need to return. control will go
						// to hello web servlet
	}

	@RequestMapping(value = "/regpage", method = RequestMethod.GET)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String regpage(ModelMap model) {

		return "Reg"; // name of jsp which we need to return. control will go to
						// hello web servlet
	}

	@RequestMapping(value = "/savepage", method = RequestMethod.POST)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String save(@ModelAttribute("regUser") RegBean reg, Model model,
			HttpServletRequest req, HttpServletResponse res) {

		System.out.println("Name:" + reg.getName());
		System.out.println("Password:" + reg.getPassword());
		System.out.println("Company Name:" + reg.getCompany());
		System.out.println("Gender:" + reg.getRadios());
		System.out.println("Location:" + reg.getLoc());
		System.out.println("Languages known:" + reg.getLanguages());

		HttpSession ses = req.getSession();
		ses.setAttribute("reg", reg);

		model.addAttribute("message", "user registered");
		// model.addAttribute("reg", reg);

		return "Login"; // name of jsp which we need to return. control will go
						// to
						// hello web servlet
	}

	@RequestMapping(value = "/loginsuccess", method = RequestMethod.POST)
	// without adding the "value" parameter, we need to explicitly mention the
	// url name.
	public String success(RegBean loginBean, BindingResult result,
			Model model, HttpServletRequest req, HttpServletResponse res) {

		System.out.println("TEST : " + result.getFieldErrorCount());
		if (result.hasErrors()) {
			System.out.println("*******" + result.getAllErrors());
			
			return "Login";

		}
		HttpSession ses = req.getSession();
		RegBean rbean = (RegBean) ses.getAttribute("reg");

		if (rbean.getName().equals(loginBean.getName())
				&& rbean.getPassword().equals(loginBean.getPassword())) {
			System.out.println("Name CHECK:" + loginBean.getName());

			model.addAttribute("rbean", rbean);
			return "Loginsuccess";

		}

		model.addAttribute("message", "imnvalid user");
		return "Login";

		// name of jsp which we need to return. control will go to
		// hello web servlet
	}

}
